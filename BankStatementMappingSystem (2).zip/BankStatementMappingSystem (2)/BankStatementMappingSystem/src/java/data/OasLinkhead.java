/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author 011685
 */
public class OasLinkhead {

    private String linkcode;
    private String cmpcode;
    private String doccode;
    private String docnumber;
    private int posted;
    private int yr;
    private int period;
    private String curdoc;
    private String docdate;

    public OasLinkhead(String linkcode, String cmpcode, String doccode, String docnumber, int posted, int yr, int period, String curdoc, String docdate) {
        this.linkcode = linkcode;
        this.cmpcode = cmpcode;
        this.doccode = doccode;
        this.docnumber = docnumber;
        this.posted = posted;
        this.yr = yr;
        this.period = period;
        this.curdoc = curdoc;
        this.docdate = docdate;
        //this.docdate = "29-10-11";
    }

    /**
     * @return the linkcode
     */
    public String getLinkcode() {
        return linkcode;
    }

    /**
     * @param linkcode the linkcode to set
     */
    public void setLinkcode(String linkcode) {
        this.linkcode = linkcode;
    }

    /**
     * @return the cmpcode
     */
    public String getCmpcode() {
        return cmpcode;
    }

    /**
     * @param cmpcode the cmpcode to set
     */
    public void setCmpcode(String cmpcode) {
        this.cmpcode = cmpcode;
    }

    /**
     * @return the doccode
     */
    public String getDoccode() {
        return doccode;
    }

    /**
     * @param doccode the doccode to set
     */
    public void setDoccode(String doccode) {
        this.doccode = doccode;
    }

    /**
     * @return the docnumber
     */
    public String getDocnumber() {
        return docnumber;
    }

    /**
     * @param docnumber the docnumber to set
     */
    public void setDocnumber(String docnumber) {
        this.docnumber = docnumber;
    }

    /**
     * @return the posted
     */
    public int getPosted() {
        return posted;
    }

    /**
     * @param posted the posted to set
     */
    public void setPosted(int posted) {
        this.posted = posted;
    }

    /**
     * @return the yr
     */
    public int getYr() {
        return yr;
    }

    /**
     * @param yr the yr to set
     */
    public void setYr(int yr) {
        this.yr = yr;
    }

    /**
     * @return the period
     */
    public int getPeriod() {
        return period;
    }

    /**
     * @param period the period to set
     */
    public void setPeriod(int period) {
        this.period = period;
    }

    /**
     * @return the curdoc
     */
    public String getCurdoc() {
        return curdoc;
    }

    /**
     * @param curdoc the curdoc to set
     */
    public void setCurdoc(String curdoc) {
        this.curdoc = curdoc;
    }

    /**
     * @return the docdate
     */
    public String getDocdate() {
        return docdate;
    }

    /**
     * @param docdate the docdate to set
     */
    public void setDocdate(String docdate) {
        this.docdate = docdate;
    }
}
