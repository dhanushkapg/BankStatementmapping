/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author 011685
 */
public class OasLinkline {

    private String linkcode;
    private String cmpcode;
    private String doccode;
    private String docnumber;
    private long doclinrnum;
    private String acccode;
    private double valuedoc;
    private int debitcredit;
    private String descr;
    private String extref1;
    private String extref2;
    private String docdate;

    public OasLinkline() {
    }

    

    public OasLinkline(String linkcode, String cmpcode, String doccode, String docnumber, long doclinrnum, String acccode, double valuedoc, int debitcredit, String descr, String extref1, String extref2) {
        this.linkcode = linkcode;
        this.cmpcode = cmpcode;
        this.doccode = doccode;
        this.docnumber = docnumber;
        this.doclinrnum = doclinrnum;
        this.acccode = acccode;
        this.valuedoc = valuedoc;
        this.debitcredit = debitcredit;
        this.descr = descr;
        this.extref1 = extref1;
        this.extref2 = extref2;
    }

    /**
     * @return the linkcode
     */

    
    public String getLinkcode() {
        return linkcode;
    }

    /**
     * @param linkcode the linkcode to set
     */
    public void setLinkcode(String linkcode) {
        this.linkcode = linkcode;
    }

    /**
     * @return the cmpcode
     */
    public String getCmpcode() {
        return cmpcode;
    }

    /**
     * @param cmpcode the cmpcode to set
     */
    public void setCmpcode(String cmpcode) {
        this.cmpcode = cmpcode;
    }

    /**
     * @return the doccode
     */
    public String getDoccode() {
        return doccode;
    }

    /**
     * @param doccode the doccode to set
     */
    public void setDoccode(String doccode) {
        this.doccode = doccode;
    }

    /**
     * @return the docnumber
     */
    public String getDocnumber() {
        return docnumber;
    }

    /**
     * @param docnumber the docnumber to set
     */
    public void setDocnumber(String docnumber) {
        this.docnumber = docnumber;
    }

    /**
     * @return the doclinrnum
     */
    public long getDoclinrnum() {
        return doclinrnum;
    }

    /**
     * @param doclinrnum the doclinrnum to set
     */
    public void setDoclinrnum(long doclinrnum) {
        this.doclinrnum = doclinrnum;
    }

    /**
     * @return the acccode
     */
    public String getAcccode() {
        return acccode;
    }

    /**
     * @param acccode the acccode to set
     */
    public void setAcccode(String acccode) {
        this.acccode = acccode;
    }

    /**
     * @return the valuedoc
     */
    public double getValuedoc() {
        return valuedoc;
    }

    /**
     * @param valuedoc the valuedoc to set
     */
    public void setValuedoc(double valuedoc) {
        this.valuedoc = valuedoc;
    }

    /**
     * @return the debitcredit
     */
    public int getDebitcredit() {
        return debitcredit;
    }

    /**
     * @param debitcredit the debitcredit to set
     */
    public void setDebitcredit(int debitcredit) {
        this.debitcredit = debitcredit;
    }

    /**
     * @return the descr
     */
    public String getDescr() {
        return descr;
    }

    /**
     * @param descr the descr to set
     */
    public void setDescr(String descr) {
        this.descr = descr;
    }

    /**
     * @return the extref1
     */
    public String getExtref1() {
        return extref1;
    }

    /**
     * @param extref1 the extref1 to set
     */
    public void setExtref1(String extref1) {
        this.extref1 = extref1;
    }

    /**
     * @return the extref2
     */
    public String getExtref2() {
        return extref2;
    }

    /**
     * @param extref2 the extref2 to set
     */
    public void setExtref2(String extref2) {
        this.extref2 = extref2;
    }

    /**
     * @return the docdate
     */
    public String getDocdate() {
        return docdate;
    }

    /**
     * @param docdate the docdate to set
     */
    public void setDocdate(String docdate) {
        this.docdate = docdate;
    }
}
