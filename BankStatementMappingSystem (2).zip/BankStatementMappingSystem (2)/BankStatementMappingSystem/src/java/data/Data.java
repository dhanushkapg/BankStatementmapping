/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 011685
 */
public class Data implements DataIn {

    private Connection conn;
    private ResultSet result;
    private Statement stmt;
    private String url;

    public void conectionToDb() throws ClassNotFoundException, SQLException {

        url = "jdbc:oracle:thin:@172.25.1.162:1522:TFIN";//Databse url


        try {

            Class.forName("oracle.jdbc.OracleDriver"); //Regitering the update_data base driver

            setConn(java.sql.DriverManager.getConnection(url, "BANKSTA", "banksta678"));

            //stmt = getConn().createStatement();


        } catch (NullPointerException ex) {
            throw new NullPointerException("Null");
        } catch (ClassNotFoundException ce) {
            throw new ClassNotFoundException();
        } catch (SQLException sqe) {
            String m = sqe.getMessage();
            throw new SQLException(sqe.getMessage());
        }
    }

    public void conectionToDbLog() throws ClassNotFoundException, SQLException {

        url = "jdbc:mysql://172.25.1.136:3306/BNKSTA";//Databse url
        try {

            Class.forName("com.mysql.jdbc.Driver"); //Regitering the update_data base driver

            conn = java.sql.DriverManager.getConnection(url, "admin", "0pexonDell");

            //stmt = conn.createStatement();


        } catch (NullPointerException ex) {
            
            throw new NullPointerException("Null");
        } catch (ClassNotFoundException ce) {
            
            throw new ClassNotFoundException();
        } catch (SQLException sqe) {
            
            String m = sqe.getMessage();
            throw new SQLException(sqe.getMessage());
        }

    }

    public void insertLnkHdData(OasLinkhead oasLnkHd) throws ClassNotFoundException, SQLException {
        try {

            conectionToDb();
            String SELECT_RECORD = "select * from TFINCODA.oas_linkhead where linkcode='" + oasLnkHd.getLinkcode() + "'"
                    + " and cmpcode='" + oasLnkHd.getCmpcode() + "' and doccode='" + oasLnkHd.getDoccode() + "' "
                    + "and docnum='" + oasLnkHd.getDocnumber() + "'"
                    + "and docdate=To_date('" + oasLnkHd.getDocdate() + "','DD-MM-YY')";
            Statement stmt1 = conn.createStatement();
            
            ResultSet set = stmt1.executeQuery(SELECT_RECORD);
            if (!set.next()) {

                String INSERT_RECORD = "insert into TFINCODA.oas_linkhead "
                        + "(linkcode,cmpcode,doccode,docnum,posted,yr,period,curdoc,docdate)"
                        + "values('" + oasLnkHd.getLinkcode() + "','" + oasLnkHd.getCmpcode() + "','" + oasLnkHd.getDoccode() + "',"
                        + "'" + oasLnkHd.getDocnumber() + "'," + oasLnkHd.getPosted() + "," + oasLnkHd.getYr() + "," + oasLnkHd.getPeriod() + ","
                        + "'" + oasLnkHd.getCurdoc() + "',To_date('" + oasLnkHd.getDocdate() + "','DD-MM-YY'))";

                Statement stmt2 = conn.createStatement();
               // System.out.println(INSERT_RECORD);
                stmt2.executeUpdate(INSERT_RECORD);



            }
            conn.close();

        } catch (ClassNotFoundException ex) {
            throw new ClassNotFoundException(ex.getMessage());
        } catch (SQLException ex) {

            throw new SQLException(ex.getMessage());
        }
    }

    public void insertLnkLnData(OasLinkline oasLnkLn) throws ClassNotFoundException, SQLException {
        try {

            conectionToDb();

            String INSERT_RECORD = "insert into TFINCODA.oas_linkline (linkcode,cmpcode,doccode,docnum,doclinenum,"
                    + "accode,valuedoc,valuedoc_dp,valuehome,valuehome_dp,"
                    + "debitcredit,descr,extref1,extref2)  values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            PreparedStatement pstmt = conn.prepareStatement(INSERT_RECORD);
            pstmt.setString(1, oasLnkLn.getLinkcode());

            pstmt.setString(2, oasLnkLn.getCmpcode());

            pstmt.setString(3, oasLnkLn.getDoccode());

            pstmt.setString(4, oasLnkLn.getDocnumber());

            pstmt.setInt(5, (int) oasLnkLn.getDoclinrnum());

            pstmt.setString(6, oasLnkLn.getAcccode());

            pstmt.setDouble(7, oasLnkLn.getValuedoc());

            pstmt.setInt(8, 2);

            pstmt.setDouble(9, oasLnkLn.getValuedoc());

            pstmt.setInt(10, 2);

            pstmt.setInt(11, oasLnkLn.getDebitcredit());

            pstmt.setString(12, (oasLnkLn.getDescr().toUpperCase()));

            pstmt.setString(13, (oasLnkLn.getExtref1().toUpperCase()));

            pstmt.setString(14, (oasLnkLn.getExtref2().toUpperCase()));


            //pstmt.setString(6, (String) setInsertData.setLocation((String) insertData.get(5))); //location

            
           // System.out.println(oasLnkLn.getDoccode()+" : "+oasLnkLn.getDescr()+" : "+oasLnkLn.getExtref1()+" : "+oasLnkLn.getExtref2()+" : "+oasLnkLn.getValuedoc());
            pstmt.executeUpdate();

            conn.close();

        } catch (ClassNotFoundException ex) {
            throw new ClassNotFoundException(ex.getMessage());
        } catch (SQLException ex) {
            throw new SQLException(ex.getMessage());
        }
    }

    public boolean  getData(String query)  {
        System.out.println(query);
        try {
            conectionToDbLog();
            Statement stlog=conn.createStatement();
            result = stlog.executeQuery(query);
            if(result.next()){
                conn.close();
                
                return true;
            }else{
                conn.close();
                return false;
            }
            
        } catch (ClassNotFoundException ex) {
            //throw new ClassNotFoundException("Error with database driver");
            return false;
        } catch (SQLException ex) {
            String s = ex.getMessage();
            System.out.println(s);
            return false;
        }
        
    }


    /**
     * @return the conn
     */
    public Connection getConn() {
        return conn;
    }

    /**
     * @param conn the conn to set
     */
    public void setConn(Connection conn) {
        this.conn = conn;
    }
}
