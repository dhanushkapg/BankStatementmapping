/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

import java.sql.SQLException;



/**
 *
 * @author 011685
 */
public interface DataIn {

    public void insertLnkHdData(OasLinkhead oasLnkHd)throws ClassNotFoundException, SQLException;

    public void insertLnkLnData(OasLinkline oasLnkLn)throws ClassNotFoundException, SQLException;
}
