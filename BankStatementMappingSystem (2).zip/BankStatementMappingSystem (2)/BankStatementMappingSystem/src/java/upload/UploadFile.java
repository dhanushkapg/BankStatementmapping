/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package upload;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mapping.Mapping;
import org.apache.tomcat.util.http.fileupload.DiskFileUpload;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.poi.hssf.usermodel.*;

/**
 *
 * @author 011685
 */
public class UploadFile extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
//        PrintWriter out = response.getWriter();
//        OutputStream out = response.getOutputStream();
        try {
            int dataListRow = 0;
            int errorRow = 0;
            DiskFileUpload upload = new DiskFileUpload();
            List items = upload.parseRequest(request);
            Iterator iterator = items.iterator();
            String action=null;;
            while (iterator.hasNext()) {
                FileItem file = (FileItem) iterator.next();
                String source = file.getName();
                
//                String path = "D:\\GIHAL\\DEVELOPMENTS\\INDEV\\BankStatementMappingSystem\\web\\files\\latest_log_file_test.xls";
                String path = "/usr/local/apache-tomcat-6.0.16/webapps/BankStatementMappingSystem/files/latest_log_file_test.xls";
                FileItem name = (FileItem) items.get(0);
                String target = name.getString();
                File outfile = new File(path);
                file.write(outfile);
            }
            //response.setContentType("application/vnd.ms-excel");x-msexcel
            response.setContentType("application/x-msexcel");

            HSSFWorkbook wb = new HSSFWorkbook();


            HSSFSheet masterSheet = wb.createSheet("MasterDataCashInHand");
            HSSFSheet dtSheet = wb.createSheet("Data Table");
            HSSFSheet errorSheet = wb.createSheet("Error Table");

            HSSFRow datarow = dtSheet.createRow(0);
            HSSFCell datacell = datarow.createCell(0);

            HSSFRow masterrow = masterSheet.createRow(0);
            HSSFCell mastercell = masterrow.createCell(0);

            HSSFRow errorrow = errorSheet.createRow(0);
            HSSFCell errorcell = errorrow.createCell(0);

            masterrow.createCell(0).setCellValue(new HSSFRichTextString("Code"));
            masterrow.createCell(1).setCellValue(new HSSFRichTextString("CollectionCenter"));
            masterrow.createCell(2).setCellValue(new HSSFRichTextString("Province"));
            masterrow.createCell(3).setCellValue(new HSSFRichTextString("FTAccountCode"));
            masterrow.createCell(4).setCellValue(new HSSFRichTextString("CHAccount"));
            masterrow.createCell(5).setCellValue(new HSSFRichTextString("BankCode"));
            masterrow.createCell(6).setCellValue(new HSSFRichTextString("BankName"));
         
            datarow.createCell(0).setCellValue(new HSSFRichTextString("Date"));
            datarow.createCell(1).setCellValue(new HSSFRichTextString("Description"));
            datarow.createCell(2).setCellValue(new HSSFRichTextString("Code"));
            datarow.createCell(3).setCellValue(new HSSFRichTextString("Amount"));
            datarow.createCell(4).setCellValue(new HSSFRichTextString("PayMode"));
            datarow.createCell(5).setCellValue(new HSSFRichTextString("DebitCredit"));

            errorrow.createCell(0).setCellValue(new HSSFRichTextString("Date"));
            errorrow.createCell(1).setCellValue(new HSSFRichTextString("Description"));
            errorrow.createCell(2).setCellValue(new HSSFRichTextString("Code"));
            errorrow.createCell(3).setCellValue(new HSSFRichTextString("Amount"));


            ArrayList masterList = new Mapping().readMasterExcelFile(0);

            for (int i = 0; i < masterList.size(); i++) {
                String cells[] = (String[]) masterList.get(i);
                HSSFRow myRow = masterSheet.createRow(i+1);
                HSSFCell myCell = myRow.createCell(100);

                myRow.createCell(0).setCellValue(new HSSFRichTextString(cells[0]));
                myRow.createCell(1).setCellValue(new HSSFRichTextString(cells[1]));
                myRow.createCell(2).setCellValue(new HSSFRichTextString(cells[2]));
                myRow.createCell(3).setCellValue(new HSSFRichTextString(cells[3]));
                myRow.createCell(4).setCellValue(new HSSFRichTextString(""));
                myRow.createCell(5).setCellValue(new HSSFRichTextString(""));
                myRow.createCell(6).setCellValue(new HSSFRichTextString(""));

            }



            ArrayList dataList = new Mapping().readDtExcelFile(action,0);

            for (int i = 0; i < dataList.size(); i++) {
                String cells[] = (String[]) dataList.get(i);

                if (!cells[6].equals("ERROR")) {
                    HSSFRow myRow1 = dtSheet.createRow(++dataListRow);
                    HSSFCell myCell1 = myRow1.createCell(100);
//                myRow1.createCell(0).setCellValue(new HSSFRichTextString(cells[0]));
                    myRow1.createCell(0).setCellValue(Integer.parseInt(cells[0]));
                    myRow1.createCell(1).setCellValue(new HSSFRichTextString(cells[1]));
                    myRow1.createCell(2).setCellValue(new HSSFRichTextString(cells[2]));
                    myRow1.createCell(3).setCellValue(new HSSFRichTextString(cells[3]));
                    myRow1.createCell(4).setCellValue(new HSSFRichTextString(cells[4]));
                    myRow1.createCell(5).setCellValue(new HSSFRichTextString(cells[5]));
                } else {
                    HSSFRow myRow = errorSheet.createRow(++errorRow);
                    HSSFCell myCell = myRow.createCell(100);
                    myRow.createCell(0).setCellValue(Integer.parseInt(cells[0]));
                    myRow.createCell(1).setCellValue(new HSSFRichTextString(cells[1]));
                    myRow.createCell(2).setCellValue(new HSSFRichTextString(cells[2]));
                    myRow.createCell(3).setCellValue(new HSSFRichTextString(cells[3]));
                }

            }
            OutputStream out = response.getOutputStream();
            wb.write(out);
            out.close();



        } catch (Exception ex) {
            request.setAttribute("msg", ex.getMessage());
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
            dispatcher.forward(request, response);
            Logger.getLogger(UploadFile.class.getName()).log(Level.SEVERE, null, ex);
//        } finally {
//            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
