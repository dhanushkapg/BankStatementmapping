/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package upload;

import data.OasLinkhead;
import data.OasLinkline;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mapping.Mapping;
import mapping.MappingPb;
import mapping.MappingPdCoda;
import org.apache.tomcat.util.http.fileupload.DiskFileUpload;
import org.apache.tomcat.util.http.fileupload.FileItem;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

/**

/**
 *
 * @author 011685
 */
public class PbFile extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        //  PrintWriter out = response.getWriter();
        try {
            int dataListRow = 0;
            int errorRow = 0;
            DiskFileUpload upload = new DiskFileUpload();
            List items = upload.parseRequest(request);
            Iterator iterator = items.iterator();
            String action = null;
            String path = null;
            while (iterator.hasNext()) {
                FileItem file = (FileItem) iterator.next();
                String source = file.getName();

//                path = "D:\\GIHAL\\DEVELOPMENTS\\INDEV\\BankStatementMappingSystem\\web\\files\\latest_pb_file_test.xls";
                path = "/usr/local/apache-tomcat-6.0.16/webapps/BankStatementMappingSystem/files/latest_pb_file_test.xls";
                FileItem name = (FileItem) items.get(0);
                String target = name.getString();
                File outfile = new File(path);
                file.write(outfile);
            }

//            FileInputStream myInput = new FileInputStream(path);
//
//            /** Create a POIFSFileSystem object**/
//            POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);
//
//            /** Create a workbook using the File System**/
//            HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);
//
//            /** Get the first sheet from workbook**/
//            HSSFSheet mySheet = myWorkBook.getSheetAt(3);
//
//            /** We now need something to iterate through the cells.**/
//            Iterator rowIter = mySheet.rowIterator();
//            ArrayList cellList = new ArrayList();
//            while (rowIter.hasNext()) {
//                HSSFRow myRow = (HSSFRow) rowIter.next();
//
//                String dataSet[] = new String[5];
//
//                for (int i = 0; i < myRow.getPhysicalNumberOfCells(); i++) {
//                    //cellList.add((HSSFCell) myRow.getCell(i));
//                    dataSet[i] = ((HSSFCell) myRow.getCell(i)).toString();
////                    System.out.println(((HSSFCell) myRow.getCell(i)).toString());
//
//                }
//
//
//                cellList.add(dataSet);
//
//            }
            ArrayList data = new MappingPb().persistsData();

            response.setContentType("application/x-msexcel");

            HSSFWorkbook wb = new HSSFWorkbook();


            // HSSFSheet masterSheet = wb.createSheet("MasterDataCashInHand");
            HSSFSheet dtSheet = wb.createSheet("Data Table");
            HSSFSheet errorSheet = wb.createSheet("Error Table");

            HSSFRow datarow = dtSheet.createRow(0);
            HSSFCell datacell = datarow.createCell(0);

            //HSSFRow masterrow = masterSheet.createRow(0);
            //HSSFCell mastercell = masterrow.createCell(0);

            HSSFRow errorrow = errorSheet.createRow(0);
            HSSFCell errorcell = errorrow.createCell(0);

//            masterrow.createCell(0).setCellValue(new HSSFRichTextString("Code"));
//            masterrow.createCell(1).setCellValue(new HSSFRichTextString("CollectionCenter"));
//            masterrow.createCell(2).setCellValue(new HSSFRichTextString("Province"));
//            masterrow.createCell(3).setCellValue(new HSSFRichTextString("FTAccountCode"));
//            masterrow.createCell(4).setCellValue(new HSSFRichTextString("CHAccount"));
//            masterrow.createCell(5).setCellValue(new HSSFRichTextString("BankCode"));
//            masterrow.createCell(6).setCellValue(new HSSFRichTextString("BankName"));

            datarow.createCell(0).setCellValue(new HSSFRichTextString("DATE"));
            datarow.createCell(1).setCellValue(new HSSFRichTextString("ACCOUNT CODE"));
            datarow.createCell(2).setCellValue(new HSSFRichTextString("DOC CODE"));
            datarow.createCell(3).setCellValue(new HSSFRichTextString("AMOUNT"));
            datarow.createCell(4).setCellValue(new HSSFRichTextString("DEBIT/CREDIT"));


            errorrow.createCell(0).setCellValue(new HSSFRichTextString("DATE"));
            errorrow.createCell(1).setCellValue(new HSSFRichTextString("AMOUNT"));
            errorrow.createCell(2).setCellValue(new HSSFRichTextString("REFERENCE"));



            for (int i = 0; i < data.size(); i++) {
                OasLinkline line = (OasLinkline) ((Object[]) data.get(i))[0];
                OasLinkhead head = (OasLinkhead) ((Object[]) data.get(i))[1];
                if (line.getAcccode() == null || line.getDoccode().equals("ERROR")) {
                    HSSFRow myRow1 = errorSheet.createRow(++errorRow);
                    HSSFCell myCell = myRow1.createCell(100);
                    myRow1.createCell(0).setCellValue(line.getDocdate());                   
                    myRow1.createCell(1).setCellValue(new HSSFRichTextString(String.valueOf(line.getValuedoc())));
                    myRow1.createCell(2).setCellValue(new HSSFRichTextString(line.getAcccode()));


                } else {
                    HSSFRow myRow1 = dtSheet.createRow(++dataListRow);
                    HSSFCell myCell = myRow1.createCell(100);
                    myRow1.createCell(0).setCellValue(line.getDocdate());

                    myRow1.createCell(1).setCellValue(line.getAcccode());
                    myRow1.createCell(2).setCellValue(line.getDoccode());
//                    myRow1.createCell(3).setCellValue(new HSSFRichTextString(String.valueOf(line.getValuedoc())));
                     myRow1.createCell(3).setCellValue(line.getValuedoc());
                    if (line.getDebitcredit() == 161) {
                        myRow1.createCell(4).setCellValue(new HSSFRichTextString("C"));
                    } else {
                        myRow1.createCell(4).setCellValue(new HSSFRichTextString("D"));
                    }


                    HSSFRow myRow2 = dtSheet.createRow(++dataListRow);
                    HSSFCell myCel2 = myRow1.createCell(100);
                    myRow2.createCell(0).setCellValue(line.getDocdate());
                    myRow2.createCell(1).setCellValue("80310100.2530.2900");
                    myRow2.createCell(2).setCellValue(line.getDoccode());
                    myRow2.createCell(3).setCellValue(line.getValuedoc());
                    if (line.getDebitcredit() == 161) {
                        myRow2.createCell(4).setCellValue(new HSSFRichTextString("D"));
                    } else {
                        myRow2.createCell(4).setCellValue(new HSSFRichTextString("C"));
                    }
                }

            }
            OutputStream out = response.getOutputStream();
            wb.write(out);
            out.close();
           
        } catch (Exception ex) {
            request.setAttribute("msg", ex.getMessage());
            Logger.getLogger(PbFile.class.getName()).log(Level.SEVERE, null, ex);
        }
//        finally {
//            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/home.jsp");
//            dispatcher.forward(request, response);
//            out.close();
//        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
