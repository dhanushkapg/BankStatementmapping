/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mapping;

import com.sun.org.apache.bcel.internal.generic.RETURN;
import data.Data;
import data.DataIn;
import data.OasLinkhead;
import data.OasLinkline;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

/**
 *
 * @author 011685
 */
public class MappingPdCoda {

//    final String path = "D:\\GIHAL\\DEVELOPMENTS\\INDEV\\BankStatementMappingSystem\\web\\files\\latest_pb_file_test_coda.xls";
    final String path = "/usr/local/apache-tomcat-6.0.16/webapps/BankStatementMappingSystem/files/latest_pb_file_test.xls";

    public void uploadData() {
        try {
            FileInputStream myInput = new FileInputStream(path);

            /** Create a POIFSFileSystem object**/
            POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

            /** Create a workbook using the File System**/
            HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

            /** Get the first sheet from workbook**/
            HSSFSheet mySheet = myWorkBook.getSheetAt(0);

            /** We now need something to iterate through the cells.**/
            Iterator rowIter = mySheet.rowIterator();
            ArrayList cellList = new ArrayList();
            while (rowIter.hasNext()) {
                HSSFRow myRow = (HSSFRow) rowIter.next();

                String dataSet[] = new String[5];

                for (int i = 0; i < myRow.getPhysicalNumberOfCells(); i++) {
                    //cellList.add((HSSFCell) myRow.getCell(i));
                    dataSet[i] = ((HSSFCell) myRow.getCell(i)).toString();
//                    System.out.println(((HSSFCell) myRow.getCell(i)).toString());

                }


                cellList.add(dataSet);

            }
            
            int htrbkdepLine = 0;
            int htrrtnchqLine = 0;
            int htrbkchgeLine = 0;
            int htrbkcomLine = 0;
            int htrebnkLine = 0;
            String date = "";
            //String lnkCode = "BNKSTA";
            String cmpCode = "TELECOM";
            ArrayList oasLinkHead = new ArrayList();
            ArrayList oasLinkLine = new ArrayList();
            LinkedHashSet lhashSet = new LinkedHashSet();
            Data data = new Data();
            for (int i = 1; i < cellList.size(); i++) {
                OasLinkline oasLnkLn = new OasLinkline();
                oasLnkLn.setCmpcode(cmpCode);
                lhashSet.add(((String[]) cellList.get(i))[2]);
                date = ((String[]) cellList.get(i))[0];
                if (((String[]) cellList.get(i))[2] != null && ((String[]) cellList.get(i))[2].equals("HTRBKDEP")) {
                    if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(160);

                    } else if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(161);
                    }
                    oasLnkLn.setDoclinrnum(++htrbkdepLine);
                } else if (((String[]) cellList.get(i))[2] != null && ((String[]) cellList.get(i))[2].equals("HTRRETNCHQ")) {
                    if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(160);

                    } else if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(161);
                    }
                    oasLnkLn.setDoclinrnum(++htrrtnchqLine);
                } else if (((String[]) cellList.get(i))[2] != null && ((String[]) cellList.get(i))[2].equals("HTRBKCHG")) {
                    if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(160);

                    } else if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(161);
                    }
                    oasLnkLn.setDoclinrnum(++htrbkchgeLine);
                } else if (((String[]) cellList.get(i))[2] != null && ((String[]) cellList.get(i))[2].equals("HTRBKCOM")) {
                    if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(160);

                    } else if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(161);
                    }
                    oasLnkLn.setDoclinrnum(++htrbkcomLine);
                } else if (((String[]) cellList.get(i))[2] != null && ((String[]) cellList.get(i))[2].equals("HTRREBANK")) {
                    if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(160);

                    } else if (((String[]) cellList.get(i))[4] != null && ((String[]) cellList.get(i))[4].equals("C")) {
                        oasLnkLn.setDebitcredit(161);
                    }
                    oasLnkLn.setDoclinrnum(++htrebnkLine);
                }
                oasLnkLn.setDocnumber("1");
                oasLnkLn.setAcccode(((String[]) cellList.get(i))[1]);
                oasLnkLn.setDoccode(((String[]) cellList.get(i))[2]);
                oasLnkLn.setDescr("PB");
                oasLnkLn.setExtref1("PB");
                oasLnkLn.setExtref2("PB");
                oasLnkLn.setLinkcode("PBTTST" + formatLinkDate(((String[]) cellList.get(i))[0]));
                oasLnkLn.setValuedoc(Double.parseDouble(((String[]) cellList.get(i))[3]));
                data.insertLnkLnData(oasLnkLn);
            }
            Iterator lnkHdItr = lhashSet.iterator();
            while (lnkHdItr.hasNext()) {
                OasLinkhead oasLnkHd = new OasLinkhead("PBTTST" + formatLinkDate(date), cmpCode, (String) lnkHdItr.next(), "1", 46, Integer.parseInt(((formatDate(date).split("-"))[2])), Integer.parseInt(((formatDate(date).split("-"))[1])), "LKR", date);
                data.insertLnkHdData(oasLnkHd);
            }
        } catch (Exception e) {
        }
    }

    private String formatLinkDate(String date) {
        Date _date = new Date(date);
       
        SimpleDateFormat formatter = new SimpleDateFormat("ddMMyy");
        return formatter.format(_date);
    }

    private String formatDate(String date) {
        Date _date = new Date(date);
       
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        return formatter.format(_date);
    }
}
