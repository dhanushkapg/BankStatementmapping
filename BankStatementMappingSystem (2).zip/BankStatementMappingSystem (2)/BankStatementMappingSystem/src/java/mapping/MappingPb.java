/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mapping;

import com.sun.org.apache.bcel.internal.generic.RETURN;
import data.Data;
import data.DataIn;
import data.OasLinkhead;
import data.OasLinkline;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

/**
 *
 * @author 011685
 */
public class MappingPb {

    final String[] ACCOUNT_LIST = {"0000004100180209813", "0000004100100209812", "0000004100140209810", "0000004100120209806", "0000004100160209809"};
//    final String path = "D:\\GIHAL\\DEVELOPMENTS\\INDEV\\BankStatementMappingSystem\\web\\files\\latest_pb_file_test.xls";
    final String path = "/usr/local/apache-tomcat-6.0.16/webapps/BankStatementMappingSystem/files/latest_pb_file_test.xls";
    ArrayList fileData = new ArrayList();

    public ArrayList persistsData() throws FileNotFoundException, IOException {

        try {
            FileInputStream myInput = new FileInputStream(path);

            /** Create a POIFSFileSystem object**/
            POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

            /** Create a workbook using the File System**/
            HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

            /** Get the first sheet from workbook**/
            HSSFSheet mySheet = myWorkBook.getSheetAt(1);


            /** We now need something to iterate through the cells.**/
            Iterator rowIter = mySheet.rowIterator();
            ArrayList cellList = new ArrayList();
            while (rowIter.hasNext()) {
                HSSFRow myRow = (HSSFRow) rowIter.next();


                int a = myRow.getPhysicalNumberOfCells();
                if (myRow.getPhysicalNumberOfCells() >= 5) {
                    String dataSet[] = new String[5];
                    for (int i = 0; i < myRow.getPhysicalNumberOfCells(); i++) {
                        //cellList.add((HSSFCell) myRow.getCell(i));

                        dataSet[i] = ((HSSFCell) myRow.getCell(i)).toString();

                        System.out.println(((HSSFCell) myRow.getCell(i)).toString());

                    }
                    cellList.add(dataSet);
                }
                 
//               */
//               for (int i = 0; i <5; i++) {
//                    //cellList.add((HSSFCell) myRow.getCell(i));
//
//                    dataSet[i] = ((HSSFCell) myRow.getCell(i)).toString();
//
////                    System.out.println(((HSSFCell) myRow.getCell(i)).toString());
//
//                }


               

            }





            Iterator iterator = cellList.iterator();
//            int lineNumber = 1;
            int htrbkdepLine = 0;
            int htrrtnchqLine = 0;
            int htrbkchgeLine = 0;
            int htrbkcomLine = 0;

            int htrbkdepcrdr = 0;
            int htrrtnchqcrdr = 0;
            int htrbkchgecrdr = 0;
            int htrbkcomcrdr = 0;

            String htrbkdepdoc = "";
            String htrrtnchqdoc = "";
            String htrbkchgedoc = "";
            String htrbkcomdoc = "";

            String htrbkdeplnkcode = "";
            String htrrtnchqlnkcode = "";
            String htrbkchgelnkcode = "";
            String htrbkcomlnkcode = "";

            double htrbkdepTot = 0;
            double htrrtnchqTot = 0;
            double htrbkchgeTot = 0;
            double htrbkcomTot = 0;

            Calendar currentDate = Calendar.getInstance();
            SimpleDateFormat formatter1 = new SimpleDateFormat("ddMMyy");
            SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MMM-yyyy");
            SimpleDateFormat formatter3 = new SimpleDateFormat("MM-yyyy");
            String lnkCode = null;
            String cmpCode = "TELECOM";
            String doccode = null;
            String docnumber = "2";
            Data d = new Data();
            d.conectionToDb();
            while (iterator.hasNext()) {
                OasLinkline oasLnkLn = new OasLinkline();
                oasLnkLn.setDocnumber(docnumber);
                String[] oasLnkLnData = (String[]) iterator.next();
                if (oasLnkLnData[0] != null && oasLnkLnData[1] != null && oasLnkLnData[2] != null && oasLnkLnData[3] != null) {
                    if (!oasLnkLnData[0].equalsIgnoreCase("Date")) {
                        Date date = formatter2.parse(oasLnkLnData[0]);
                        lnkCode = "BNKPB" + formatter1.format(date);
                        oasLnkLn.setLinkcode(lnkCode);
                        oasLnkLn.setDescr("BANKPB");
                        oasLnkLn.setExtref1("TEX1");
                        oasLnkLn.setExtref2("TEX2");
                        oasLnkLn.setCmpcode(cmpCode);
                        oasLnkLn.setDocdate(oasLnkLnData[0]);
                        for (int i = 0; i < ACCOUNT_LIST.length; i++) {
//                            String s = oasLnkLnData[4].substring(0, 19);
                            if (oasLnkLnData[4].length() > 18 && (oasLnkLnData[4].substring(0, 19)).contains(ACCOUNT_LIST[i])) {
                                oasLnkLn.setDoccode("HTRBKDEP");
                                doccode = "HTRBKDEP";
                                htrbkdepTot = htrbkdepTot + Double.parseDouble(oasLnkLnData[2]);
                                oasLnkLn.setDoclinrnum(++htrbkdepLine);

                                if (oasLnkLnData[1].equals("C")) {
                                    oasLnkLn.setDebitcredit(161);
                                } else {
                                    oasLnkLn.setDebitcredit(160);
                                }
                                oasLnkLn.setValuedoc(Double.parseDouble(oasLnkLnData[2]));
                                if (oasLnkLnData[4].substring(0, 19).endsWith("813")) {
                                    oasLnkLn.setAcccode("20141900.2530.3126");
                                } else if (oasLnkLnData[4].substring(0, 19).endsWith("810")) {
                                    oasLnkLn.setAcccode("20141800.2530.3162");
                                } else if (oasLnkLnData[4].substring(0, 19).endsWith("806")) {
                                    oasLnkLn.setAcccode("80520200.2530.2905");
                                } else if (oasLnkLnData[4].substring(0, 19).endsWith("812")) {
                                    oasLnkLn.setAcccode("20141700.2530.3160");
                                } else if (oasLnkLnData[4].substring(0, 19).endsWith("809")) {
                                    oasLnkLn.setAcccode("20141900.2530.2950");
                                } else {
                                    oasLnkLn.setAcccode("ERROR");
                                }
                                break;
                            } else {
                                oasLnkLn.setDoccode("ERROR");
                                oasLnkLn.setAcccode(oasLnkLnData[4]);
                                oasLnkLn.setValuedoc(Double.parseDouble(oasLnkLnData[2]));
                            }
                            /*
                             * code to be use in the future
                             */
                            //                                else {
//                                if (oasLnkLnData[4].endsWith("RTGS")) {
//                                    oasLnkLn.setDoccode("HTRBKCHG");
//                                    doccode = "HTRBKCHG";
//                                    oasLnkLn.setDoclinrnum(++htrbkchgeLine);
//                                    htrbkchgeTot = htrbkchgeTot + Double.parseDouble(oasLnkLnData[2]);
//                                    oasLnkLn.setAcccode("80310100.7185.7837");
//                                } else if (oasLnkLnData[4].endsWith("TRF")) {
//                                    oasLnkLn.setDoccode("HTRBKCOM");
//                                    doccode = "HTRBKCOM";
//                                    oasLnkLn.setDoclinrnum(++htrbkcomLine);
//                                    htrbkcomTot = htrbkcomTot + Double.parseDouble(oasLnkLnData[2]);
//                                    oasLnkLn.setAcccode("80310100.7185.7838");
//                                } else {
//                                    oasLnkLn.setAcccode("ERROR");
//                                }
//                            }
////////                            if (oasLnkLnData[1].equals("C")) {
////////                                oasLnkLn.setDebitcredit(161);
////////                            } else {
////////                                oasLnkLn.setDebitcredit(160);
////////                            }
////////                            oasLnkLn.setValuedoc(Double.parseDouble(oasLnkLnData[2]));


                        }
                        String s = formatter1.format(formatter2.parse(oasLnkLnData[0]));
                        OasLinkhead oasLnkHd = new OasLinkhead(lnkCode, cmpCode, doccode, "2", 46, Integer.parseInt(formatter1.format(formatter2.parse(oasLnkLnData[0])).substring(3, 4)), Integer.parseInt(oasLnkLnData[0].substring(8, 11)), "LKR", oasLnkLnData[0]);
//                        d.insertLnkLnData(oasLnkLn);
//                        d.insertLnkHdData(oasLnkHd);
                        Object data[] = new Object[2];
                        data[0] = oasLnkLn;
                        data[1] = oasLnkHd;
                        fileData.add(data);

                    }
                }

            }

            ArrayList secndEntry = new ArrayList();
            secndEntry.add(new OasLinkline(htrbkdeplnkcode, cmpCode, htrbkdepdoc, docnumber, ++htrbkdepLine, "80310100.2530.2925", htrbkdepTot, htrbkdepcrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrbkchgelnkcode, cmpCode, htrbkchgedoc, docnumber, ++htrbkchgeLine, "80310100.2530.2925", htrbkchgeTot, htrbkchgecrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrrtnchqlnkcode, cmpCode, htrrtnchqdoc, docnumber, ++htrrtnchqLine, "80310100.2530.2925", htrrtnchqTot, htrrtnchqcrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrbkcomlnkcode, cmpCode, htrbkcomdoc, docnumber, ++htrbkcomLine, "80310100.2530.2925", htrbkcomTot, htrbkcomcrdr, "", "", ""));
            for (int i = 0; i < secndEntry.size(); i++) {
                OasLinkline object = (OasLinkline) secndEntry.get(i);
                if (object.getDoccode() != null && object.getDoccode().length() > 0) {
                    new Data().insertLnkLnData(object);
                }
            }
            d.getConn().close();
        } catch (ParseException ex) {
            Logger.getLogger(MappingPb.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MappingPb.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mapping.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fileData;
    }
}
