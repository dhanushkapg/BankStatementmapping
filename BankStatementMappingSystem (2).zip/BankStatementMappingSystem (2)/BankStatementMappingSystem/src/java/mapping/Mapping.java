/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mapping;

//import com.entity.OasLinkhead;
import data.OasLinkline;
import data.Data;
import data.DataIn;
import data.OasLinkhead;
import java.io.FileInputStream;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 *
 * @author 011685
 */
public class Mapping {

    private final String FILENAME = "/usr/local/apache-tomcat-6.0.16/webapps/BankStatementMappingSystem/files/latest_log_file_test.xls";
//    private final String FILENAME = "D:\\GIHAL\\DEVELOPMENTS\\INDEV\\BankStatementMappingSystem\\web\\files\\latest_log_file_test.xls";

    public ArrayList readMasterExcelFile(int sheetNumber) throws Exception {
        /** --Define a Vector
        --Holds Vectors Of Cells
         */
        ArrayList list = new ArrayList();

        Vector cellVectorHolder = new Vector();

        try {
            /** Creating Input Stream**/
            //InputStream myInput= ReadExcelFile.class.getResourceAsStream( fileName );
            FileInputStream myInput = new FileInputStream(FILENAME);

            /** Create a POIFSFileSystem object**/
            POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

            /** Create a workbook using the File System**/
            HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

            /** Get the first sheet from workbook**/
            HSSFSheet mySheet = myWorkBook.getSheetAt(sheetNumber);

            /** We now need something to iterate through the cells.**/
            Iterator rowIter = mySheet.rowIterator();

            while (rowIter.hasNext()) {
                HSSFRow myRow = (HSSFRow) rowIter.next();
                //Iterator cellIter = myRow.cellIterator();
//                Iterator cellIter =myRow.cellIterator();
//                Vector cellStoreVector = new Vector();
                ArrayList cellList = new ArrayList();
                for (int i = 0; i < myRow.getPhysicalNumberOfCells(); i++) {
                    cellList.add((HSSFCell) myRow.getCell(i));
                }
//                while (cellIter.hasNext()) {
//                    HSSFCell myCell = (HSSFCell) cellIter.next();
//                    cellStoreVector.addElement(myCell);
//                }
                cellVectorHolder.addElement(cellList);
            }

            for (int i = 1; i < cellVectorHolder.size(); i++) {
                // Vector cellStoreVector = (Vector) cellVectorHolder.elementAt(i);
                ArrayList cellStoreList = (ArrayList) cellVectorHolder.elementAt(i);
                String[] cells = new String[4];

                if (cellStoreList.get(2) != null) {
                    cells[0] = ((HSSFCell) cellStoreList.get(2)).toString();
                }

                String slt[] = xmlReading(((HSSFCell) cellStoreList.get(1)).toString());
                if (slt != null) {
                    cells[1] = slt[0];
                    cells[2] = slt[1];
                    cells[3] = slt[2];
                    if (cells[1] != null && cells[2] != null && cells[3] != null) {
                        list.add(cells);
                    }
                }
            }

            return list;
        } catch (Exception e) {
            throw e;

        }


    }

    private String getTagValue(String sTag, Element eElement) {
        NodeList nlList = eElement.getElementsByTagName(sTag).item(0).getChildNodes();

        Node nValue = (Node) nlList.item(0);

        return nValue.getNodeValue();
    }

    private String[] xmlReading(String bankCode) throws Exception {

        if (bankCode.equals("cpntbcctc")) {
            System.out.println("");
        }

        bankCode = bankCode.replaceAll(" ", "");
        bankCode = bankCode.replaceAll("[^\\p{L}\\p{N}]", "");
        bankCode = bankCode.replaceAll("\\d", "");



        if (bankCode.length() > 6) {
            //bankCode = bankCode.substring(0, (bankCode.length() - 2));
            if (bankCode.startsWith("COLLCOMM")) {
                return new String[]{"COLLCOMM", "", "80310100.2530.2925"};
            } else {
                bankCode = bankCode.substring(0, 6);
            }
        } else {
            return null;
        }
        String[] sltData = null;
        try {

            File fXmlFile = new File("/usr/local/apache-tomcat-6.0.16/webapps/BankStatementMappingSystem/mapping.xml");
//            File fXmlFile = new File("D:\\GIHAL\\DEVELOPMENTS\\INDEV\\BankStatementMappingSystem\\xml\\mapping.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(fXmlFile);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("mapdata");

            for (int temp = 0; temp < nList.getLength(); temp++) {
                Node nNode = nList.item(temp);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    if (getTagValue("bank", eElement).equalsIgnoreCase(bankCode)) {

                        sltData = new String[3];
                        sltData[0] = getTagValue("slt", eElement);
                        sltData[1] = getTagValue("province", eElement);
                        sltData[2] = getTagValue("acc", eElement);
                        return sltData;
                    }
                }
            }

        } catch (Exception e) {
            throw e;

        }
        return sltData;
    }

    public ArrayList readDtExcelFile(String action, int sheetNumber) throws Exception {

        ArrayList list = new ArrayList();

        Vector cellVectorHolder = new Vector();

        try {
            /** Creating Input Stream**/
            //InputStream myInput= ReadExcelFile.class.getResourceAsStream( fileName );
            FileInputStream myInput = new FileInputStream(FILENAME);

            /** Create a POIFSFileSystem object**/
            POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

            /** Create a workbook using the File System**/
            HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

            /** Get the first sheet from workbook**/
            HSSFSheet mySheet = myWorkBook.getSheetAt(sheetNumber);

            /** We now need something to iterate through the cells.**/
            Iterator rowIter = mySheet.rowIterator();

            while (rowIter.hasNext()) {
                HSSFRow myRow = (HSSFRow) rowIter.next();
                //Iterator cellIter = myRow.cellIterator();
//                Iterator cellIter =myRow.cellIterator();
//                Vector cellStoreVector = new Vector();
                ArrayList cellList = new ArrayList();
                for (int i = 0; i < myRow.getPhysicalNumberOfCells(); i++) {
                    cellList.add((HSSFCell) myRow.getCell(i));
                }
//                while (cellIter.hasNext()) {
//                    HSSFCell myCell = (HSSFCell) cellIter.next();
//                    cellStoreVector.addElement(myCell);
//                }
                cellVectorHolder.addElement(cellList);
            }

            for (int i = 1; i < cellVectorHolder.size(); i++) {
//                Vector cellStoreVector = (Vector) cellVectorHolder.elementAt(i);
                ArrayList cellStoreList = (ArrayList) cellVectorHolder.elementAt(i);
                String[] datacells = null;
                if (((HSSFCell) cellStoreList.get(1)).toString().equals("cpntbcctc")) {
                    System.out.println("cpntbcctc");
                }
                String[] mode = modeCrDr(((HSSFCell) cellStoreList.get(1)).toString());

                String isExist[] = xmlReading(((HSSFCell) cellStoreList.get(1)).toString());
                if (isExist != null) {

                    if (mode != null) {
                        datacells = new String[7];
                        if (((HSSFCell) cellStoreList.get(0)).getCellType() == ((HSSFCell) cellStoreList.get(0)).CELL_TYPE_NUMERIC) {
                            int j = (int) ((HSSFCell) cellStoreList.get(0)).getNumericCellValue();
                            datacells[0] = String.valueOf(j); //date
                        } else {
                            datacells[0] = ((HSSFCell) cellStoreList.get(0)).toString(); //date
                        }
                        datacells[1] = ((HSSFCell) cellStoreList.get(1)).toString(); //description
                        if (((HSSFCell) cellStoreList.get(1)).toString().length() > 6) {

                            String code = ((HSSFCell) cellStoreList.get(1)).toString().replaceAll(" ", "");
                            code = code.replaceAll("[^\\p{L}\\p{N}]", "");
                            code = code.replaceAll("\\d", "");

                            datacells[2] = code.substring(2, 6); //code

                        } else {
                            datacells[2] = null; //code
                        }
                        System.out.println(((HSSFCell) cellStoreList.get(3)) +" : "+ datacells[1]);
                        if(datacells[1].equals("SBKEBCCS")){
                            System.out.println("");
                        }
                        datacells[3] = ((HSSFCell) cellStoreList.get(3)).toString(); //amount
                        datacells[4] = mode[0]; //pay mode
                        datacells[5] = mode[1]; //debit credit
                        datacells[6] = isExist[2]; //account code
                        list.add(datacells);
                    } else {
                        list.add(setErrorList(cellStoreList));
                    }

                } else {
                    list.add(setErrorList(cellStoreList));

                }
            }
            if (action != null) {
                persistsData(list);
            }
            return list;
        } catch (Exception e) {
            throw e;
        }

    }

    private String[] modeCrDr(String bankCode) throws Exception {

        String mode[] = new String[2];
        bankCode = bankCode.replaceAll(" ", "");
        bankCode = bankCode.replaceAll("[^\\p{L}\\p{N}]", "");
        bankCode = bankCode.replaceAll("\\d", "");
        try {
            if (bankCode.length() > 6) {

                if (bankCode != null) {
                    if (!bankCode.startsWith("COLL")) {

                        bankCode = bankCode.substring(6, bankCode.length()).toUpperCase();
                        if (bankCode.equalsIgnoreCase("CH") || bankCode.equalsIgnoreCase("CS") || bankCode.equalsIgnoreCase("MO")) {
                            mode[0] = "RD";
                            mode[1] = "CR";
                        } else if (bankCode.equals("CTC") || bankCode.equalsIgnoreCase("OC")) {
                            mode[0] = "BC";
                            mode[1] = "DR";
                        } else if (bankCode.equalsIgnoreCase("RTN")) {
                            mode[0] = "RC";
                            mode[1] = "DR";
                        } else if (bankCode.equalsIgnoreCase("RTNR")) {
                            mode[0] = "RB";
                            mode[1] = "CR";
                        } else {
                            return null;
                        }
                    } else {
                        mode[0] = "CC";
                        mode[1] = "DR";
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }

        } catch (Exception e) {
            throw e;
        }
        return mode;
    }

    private String[] setErrorList(ArrayList cellStoreList) throws Exception {
        String errorData[] = new String[7];
        try {
            if (((HSSFCell) cellStoreList.get(0)).getCellType() == ((HSSFCell) cellStoreList.get(0)).CELL_TYPE_NUMERIC) {
                int j = (int) ((HSSFCell) cellStoreList.get(0)).getNumericCellValue();
                errorData[0] = String.valueOf(j); //date
            } else {
                errorData[0] = ((HSSFCell) cellStoreList.get(0)).toString(); //date
            }
            errorData[1] = ((HSSFCell) cellStoreList.get(1)).toString(); //description
            if (((HSSFCell) cellStoreList.get(2)) != null) {
                errorData[2] = ((HSSFCell) cellStoreList.get(2)).toString();
            } else {
                errorData[2] = "";
            }
            if (((HSSFCell) cellStoreList.get(3)).toString() == null) {
                System.out.println("");
            }
            errorData[3] = ((HSSFCell) cellStoreList.get(3)).toString(); //amount
            errorData[6] = "ERROR";
        } catch (Exception e) {
            throw e;
        }
        return errorData;
    }

    private void persistsData(ArrayList list) {
        try {
            Iterator iterator = list.iterator();
//            int lineNumber = 1;
            int htrbkdepLine = 0;
            int htrrtnchqLine = 0;
            int htrbkchgeLine = 0;
            int htrbkcomLine = 0;
            int htrebnkLine = 0;

            int htrbkdepcrdr = 0;
            int htrrtnchqcrdr = 0;
            int htrbkchgecrdr = 0;
            int htrbkcomcrdr = 0;
            int htrebnkcrdr = 0;

            String htrbkdepdoc = "";
            String htrrtnchqdoc = "";
            String htrbkchgedoc = "";
            String htrbkcomdoc = "";
            String htrebnkdoc = "";

            String htrbkdeplnkcode = "";
            String htrrtnchqlnkcode = "";
            String htrbkchgelnkcode = "";
            String htrbkcomlnkcode = "";
            String htrebnklnkcode = "";

            double htrbkdepTot = 0;
            double htrrtnchqTot = 0;
            double htrbkchgeTot = 0;
            double htrbkcomTot = 0;
            double htrebnkTot = 0;

            Calendar currentDate = Calendar.getInstance();
            SimpleDateFormat formatter = new SimpleDateFormat("ddMMyy");
            String lnkCode = "BNKSTA";
//            String lnkCode = "GITST3";
            String cmpCode = "TELECOM";

            String docnumber = "1";
            Data d = new Data();
            d.conectionToDb();
            while (iterator.hasNext()) {


                String[] oasLnkLnData = (String[]) iterator.next();
                String lnkCode2 = oasLnkLnData[0].substring(6, 8) + oasLnkLnData[0].substring(4, 6) + oasLnkLnData[0].substring(2, 4);
                double valuedoc = Double.parseDouble((oasLnkLnData[3].replaceAll("[+\\-]", "")));
                if (!oasLnkLnData[6].equals("ERROR")) {
                    String doccode = "";


                    OasLinkline oasLnkLn = new OasLinkline();
                    oasLnkLn.setLinkcode(lnkCode + lnkCode2);
                    oasLnkLn.setCmpcode(cmpCode);

                    oasLnkLn.setDocnumber(docnumber);
//                    oasLnkLn.setDoclinrnum(lineNumber);

                    oasLnkLn.setValuedoc(valuedoc);
                    if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                        oasLnkLn.setDebitcredit(160);
                    } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                        oasLnkLn.setDebitcredit(161);
                    } else {
                        oasLnkLn.setDebitcredit(0);
                    }
                    oasLnkLn.setDescr((oasLnkLnData[1].replaceAll("\"", "")));
                    oasLnkLn.setExtref1(oasLnkLnData[2]);
                    oasLnkLn.setExtref2(oasLnkLnData[4]);
                    String date = oasLnkLnData[0].substring(6, 8) + "-" + oasLnkLnData[0].substring(4, 6) + "-" + oasLnkLnData[0].substring(2, 4);

                    DataIn data = new Data();

                    if (oasLnkLnData[4].equalsIgnoreCase("RD")) {
                        oasLnkLn.setDoclinrnum(++htrbkdepLine);
                        htrbkdepTot = htrbkdepTot + valuedoc;
                        if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                            htrbkdepcrdr = 161;
                        } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                            htrbkdepcrdr = 160;
                        }
                        htrbkdepdoc = "HTRBKDEP";
                        htrbkdeplnkcode = lnkCode + lnkCode2;
                        doccode = "HTRBKDEP";

                        oasLnkLn.setAcccode(oasLnkLnData[6].substring(0, 8).concat(".2510.2850"));


                    } else if (oasLnkLnData[4].equalsIgnoreCase("RC")) {
                        oasLnkLn.setDoclinrnum(++htrrtnchqLine);
                        htrrtnchqTot = htrrtnchqTot + valuedoc;
                        if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                            htrrtnchqcrdr = 161;
                        } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                            htrrtnchqcrdr = 160;
                        }
                        htrrtnchqdoc = "HTRRETNCHQ";
                        doccode = "HTRRETNCHQ";
                        htrrtnchqlnkcode = lnkCode + lnkCode2;
                        oasLnkLn.setAcccode(oasLnkLnData[6].substring(0, 8).concat(".2210.2144"));

                    } else if (oasLnkLnData[4].equalsIgnoreCase("BD")) {
                        oasLnkLn.setDoclinrnum(++htrbkdepLine);
                        htrbkdepTot = htrbkdepTot + valuedoc;
                        if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                            htrbkdepcrdr = 161;
                        } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                            htrbkdepcrdr = 160;
                        }
                        htrbkdepdoc = "HTRBKDEP";
                        doccode = "HTRBKDEP";
                        htrbkdeplnkcode = lnkCode + lnkCode2;
                        oasLnkLn.setAcccode(oasLnkLnData[6].substring(0, 8).concat(".2510.2850"));

                    } else if (oasLnkLnData[4].equalsIgnoreCase("BC")) {
                        oasLnkLn.setDoclinrnum(++htrbkchgeLine);
                        htrbkchgeTot = htrbkchgeTot + valuedoc;
                        if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                            htrbkchgecrdr = 161;
                        } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                            htrbkchgecrdr = 160;
                        }
                        htrbkchgedoc = "HTRBKCHG";
                        doccode = "HTRBKCHG";
                        htrbkchgelnkcode = lnkCode + lnkCode2;
                        oasLnkLn.setAcccode(oasLnkLnData[6].substring(0, 8).concat(".7185.7837"));


                    } else if (oasLnkLnData[4].equalsIgnoreCase("CC")) {
                        oasLnkLn.setDoclinrnum(++htrbkcomLine);
                        htrbkcomTot = htrbkcomTot + valuedoc;
                        if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                            htrbkcomcrdr = 161;
                        } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                            htrbkcomcrdr = 160;
                        }
                        htrbkcomdoc = "HTRBKCOM";
                        doccode = "0";
                        htrbkcomlnkcode = lnkCode + lnkCode2;
                        oasLnkLn.setAcccode("80520200.7185.7838");

                        //HTRBKCOM	80520200.7185.7838	DR
                    } else if (oasLnkLnData[4].equalsIgnoreCase("RB")) {
                        oasLnkLn.setDoclinrnum(++htrebnkLine);
                        htrebnkTot = htrebnkTot + valuedoc;
                        if (oasLnkLnData[5].equalsIgnoreCase("CR")) {
                            htrebnkcrdr = 161;
                        } else if (oasLnkLnData[5].equalsIgnoreCase("DR")) {
                            htrebnkcrdr = 160;
                        }
                        htrebnkdoc = "HTRREBANK";
                        doccode = "HTRREBANK";
                        htrebnklnkcode = lnkCode + lnkCode2;
                        oasLnkLn.setAcccode(oasLnkLnData[6].substring(0, 8).concat(".2210.2144"));
                    } else {
                        doccode = "";
                    }
                    oasLnkLn.setDoccode(doccode);
                    OasLinkhead oasLnkHd = new OasLinkhead(lnkCode + (date.replaceAll("-", "")), cmpCode, doccode, "1", 46, Integer.parseInt(oasLnkLnData[0].substring(0, 4)), Integer.parseInt(oasLnkLnData[0].substring(4, 6)), "LKR", date);
                    data.insertLnkLnData(oasLnkLn);
                    data.insertLnkHdData(oasLnkHd);

//                    lineNumber++;
                }
            }
//            OasLinkline htrbkDep=new OasLinkline(lnkCode, cmpCode, htrbkdepdoc, docnumber, htrbkdepLine, "", htrbkdepTot, htrbkdepcrdr, "", "", "");
//            OasLinkline htrbkChg=new OasLinkline(lnkCode, cmpCode, htrbkchgedoc, docnumber, htrbkchgeLine, "", htrbkchgeTot, htrbkchgecrdr, "", "", "");
//            OasLinkline htrbkRtnChq=new OasLinkline(lnkCode, cmpCode, htrrtnchqdoc, docnumber, htrrtnchqLine, "", htrrtnchqTot, htrrtnchqcrdr, "", "", "");
//            OasLinkline htrbkcom=new OasLinkline(lnkCode, cmpCode, htrbkcomdoc, docnumber, htrbkcomLine, "", htrbkcomTot, htrbkcomcrdr, "", "", "");
//
            ArrayList secndEntry = new ArrayList();
            secndEntry.add(new OasLinkline(htrbkdeplnkcode, cmpCode, htrbkdepdoc, docnumber, ++htrbkdepLine, "80310100.2530.2925", htrbkdepTot, htrbkdepcrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrbkchgelnkcode, cmpCode, htrbkchgedoc, docnumber, ++htrbkchgeLine, "80310100.2530.2925", htrbkchgeTot, htrbkchgecrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrrtnchqlnkcode, cmpCode, htrrtnchqdoc, docnumber, ++htrrtnchqLine, "80310100.2530.2925", htrrtnchqTot, htrrtnchqcrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrbkcomlnkcode, cmpCode, htrbkcomdoc, docnumber, ++htrbkcomLine, "80310100.2530.2925", htrbkcomTot, htrbkcomcrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrbkcomlnkcode, cmpCode, htrbkcomdoc, docnumber, ++htrbkcomLine, "80310100.2530.2925", htrbkcomTot, htrbkcomcrdr, "", "", ""));
            secndEntry.add(new OasLinkline(htrebnklnkcode, cmpCode, htrebnkdoc, docnumber, ++htrebnkLine, "80310100.2530.2925", htrebnkTot, htrebnkcrdr, "", "", ""));
            for (int i = 0; i < secndEntry.size(); i++) {
                OasLinkline object = (OasLinkline) secndEntry.get(i);
                if (object.getDoccode() != null && object.getDoccode().length() > 0) {
                    new Data().insertLnkLnData(object);
                }
            }
            d.getConn().close();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mapping.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Mapping.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
